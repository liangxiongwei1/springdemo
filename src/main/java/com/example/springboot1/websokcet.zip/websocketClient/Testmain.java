package com.example.springboot1.websocketClient;

import java.net.URISyntaxException;

/**
 * @author liang.xiongwei
 * @Title: Testmain
 * @Package com.intellif.smart
 * @Description
 * @date 2018/12/3 9:36
 */
public class Testmain {
    public static void main(String[] args) {
        try {
            WebClientEnum.CLIENT.initClient(new MsgWebSocketClient("ws://127.0.0.1:8887"));
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
